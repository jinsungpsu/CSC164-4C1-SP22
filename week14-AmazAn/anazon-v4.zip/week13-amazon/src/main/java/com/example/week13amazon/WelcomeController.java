package com.example.week13amazon;

public class WelcomeController {
}
