module com.example.week13amazon {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.week13amazon to javafx.fxml;
    exports com.example.week13amazon;
}