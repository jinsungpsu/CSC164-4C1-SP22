package com.example.week13amazon;

import java.util.ArrayList;

public class Database {
    // fake database
    public static ArrayList<Product> inventory = new ArrayList<>();
    public static ArrayList<Product> cart = new ArrayList<>();
    public static String storeName = "Mr. An Store";

}
