package com.example.week13amazon;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;
import java.util.ArrayList;

public class AnazonController extends Object{

    @FXML
    private Text storeNameText;

    private Stage stage;

    @FXML
    private ListView<Product> inventoryContents;

    @FXML
    private ListView<Product> cartListView;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField priceTextField;

    @FXML
    void addToInventoryBtn(ActionEvent event) {

    }

    @FXML
    void loadHelpPageBtn(ActionEvent event) {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();

        /*
        Same thing but in 2 different steps

        final Node source = (Node)event.getSource();
        final Stage stage = (Stage)source.getScene().getWindow();
        */

        try {
            FXMLLoader fxmlWelcomeLoader = new FXMLLoader(getClass().getResource("something-view.fxml"));
            Scene welcomeScene = new Scene(fxmlWelcomeLoader.load(), 800, 600);
            stage.setTitle("Welcome!");
            stage.setScene(welcomeScene);
            stage.show();
        } catch (IOException e) {
            System.out.println("Couldn't load the fxml");
            System.out.println(e);
        }
    }

    @FXML
    void addToCart(MouseEvent event) {
        Product newProduct = new Product(nameTextField.getText(), descriptionTextField.getText(), Double.parseDouble(priceTextField.getText()));
        Database.inventory.add(newProduct);

        inventoryContents.getItems().add(newProduct);

        inventoryContents.refresh();

    }

    @FXML
    void addSelectedItemToCart(ActionEvent event) {
        Product productSelected = inventoryContents.getSelectionModel().getSelectedItem();
        if (productSelected != null) {
            cartListView.getItems().add(productSelected);
            Database.cart.add(productSelected);
        }
    }

    @FXML
    void view10to20btn(ActionEvent event) {
        inventoryContents.getItems().clear();
        System.out.println(Database.inventory);

        for (Product each: Database.inventory) {
            if (each.getPrice() >= 10 && each.getPrice() <= 20) {
                inventoryContents.getItems().add(each);
            }
        }

        // inventoryContents.refresh();
    }

    @FXML
    void view30ormorebtn(ActionEvent event) {

    }

    @FXML
    void viewUnder10btn(ActionEvent event) {

    }
    public void initialize() {
        storeNameText.setText(Database.storeName);

        Product book1 = new Product("Harry Potter 1", "Whiny muggle goes to school.", 20);
        Product book2 = new Product("Where the wild things are", "I know nothing about this book.", 15);
        Product computer = new Product("Macbook", "shiny expensive thing", 1500);

        ProductList clearanceInventory = new ProductList();

        ArrayList<Product> clearanceInventoryItems = clearanceInventory.getInventory();
        clearanceInventoryItems.add(book2);
        //clearanceInventory.getInventory().add(book2);

        ProductList amazAnFreshInventory = new ProductList();

        Database.inventory.add(book1);
        Database.inventory.add(book2);
        Database.inventory.add(computer);

        inventoryContents.getItems().add(book1);
        inventoryContents.getItems().add(book2);
        inventoryContents.getItems().add(computer);

//        String inventoryString = "Current inventory:\n";
//
//        inventoryString += inventory.get(0) + "\n";
//        inventoryString += inventory.get(1);
//
//        inventoryContents.setText(inventoryContents.getText() + inventoryString);

    }

}
