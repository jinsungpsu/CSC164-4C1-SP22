package com.example.week13amazon;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.text.Text;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SomethingViewController {
    @FXML
    private Text storeNameText;

    @FXML
    void saveReceiptBtn(ActionEvent event) {
        System.out.println("Here's your receipt: " + Database.cart);
        File anotherFile = new File("C:\\Users\\jan\\OneDrive - Delaware Technical Community College\\Documents\\ClassCode\\OUTSIDEMYPROJECT\\newfile.txt");
        File myfile = new File("MYFAKEDATABASE/receipt.txt");

        try {
            if(myfile.createNewFile()==true) {
                // file does not exist
                FileWriter receiptWriter = new FileWriter("receipt.txt");
                receiptWriter.write("Here's your receipt: " + Database.cart);
                receiptWriter.close();
            } else {
                System.out.println("Receipt already on file!  Do something else!");
            }
        } catch (IOException e) {
            System.out.println("OOops - can't create that file!");
            System.out.println(e);
            e.printStackTrace();
        }
    }

    public void initialize() {
        storeNameText.setText(Database.storeName);
    }
}
